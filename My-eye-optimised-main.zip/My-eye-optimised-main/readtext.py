from dotenv import load_dotenv
load_dotenv() 
from google.generativeai import GenerativeModel
from google import genai 
from PIL import Image
import pyttsx3

client = genai.Client()

img = Image.open('page2.jpg')
model = GenerativeModel('gemini-1.5-flash')
response = model.generate_content(
    [img, "DESCRIBE THIS IMAGE IN 50 WORDS. NO DRAMA, NO INFERENCES—JUST DESCRIBE WHAT YOU SEE. DO NOT SAY WHAT YOU'RE GOING TO DO. IF THE IMAGE CONTAINS A PAGE WITH TEXT, TYPE OUT THE TEXT EXACTLY—DO NOT DESCRIBE THE BACKGROUND OR EXPLAIN SURROUNDINGS. JUST TYPE THE TEXT—ALL OF IT."],
    generation_config= model._generation_config,
    stream=True
)
full =""
for chunk in response:
    if chunk.text:
        full += chunk.text


def speak():
    engine  = pyttsx3.init()
    x = engine.say(response.text)
    engine.runAndWait()

speak()


